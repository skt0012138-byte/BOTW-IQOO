# iQOO Neo9 Pro / Dimensity 9300 build notes

This is a build helper for the supplied BOTWRecompAndroid source. It does not include Nintendo game data, DLC, keys, or a prebuilt APK.

## What this package changes

- Adds a GitHub Actions workflow that builds the ARM64 Android APK from source.
- Checks out the `libadrenotools` Git submodule, installs the pinned Android SDK/NDK/CMake versions, builds SDL3 and shaderc, and runs the Gradle release build.
- Does not apply untested CPU/GPU compiler flags to the game runtime. The existing project already contains Mali-specific Vulkan handling; forcing Adreno/Turnip settings on Immortalis-G720 would be inappropriate.

## Build the APK

1. Create a GitHub repository from this source and push the contents to its `main` branch. Keep the `.github/workflows/android-apk.yml` file and the `.gitmodules` file.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**, then **Run workflow** (or let the first push trigger it).
4. Wait for the job to finish. Download the `BOTWRecompAndroid-0.3.1-beta-arm64` artifact from the completed run. The APK is inside the downloaded artifact ZIP.

The workflow builds the application APK only. It does not package BOTW game files. On the phone, use your own legally obtained extracted `exefs` and `romfs` folder as described in the upstream README.

## Initial test profile for Immortalis-G720

These are conservative starting points, not guaranteed optimal settings; tune them after checking temperature and frame pacing in-game:

- Start at **30 FPS** rather than forcing 60 FPS.
- Start with a reduced internal resolution (around **0.5x–0.6x** if offered), then raise it only if frame pacing remains stable.
- Enable one upscaler at a time (FSR 1 first); compare image quality and frame pacing before changing anti-aliasing.
- Leave Vulkan driver compatibility options at their defaults initially. Do not install or select Mesa Turnip: it is for Qualcomm Adreno GPUs, not the Dimensity 9300's Immortalis-G720.
- Test the same scene for 10–15 minutes before increasing load; stop if the phone becomes excessively hot or the game starts stuttering/crashing.

For troubleshooting, save the app log from **Settings > Files** and record the game version, Android version, and GPU driver version.
